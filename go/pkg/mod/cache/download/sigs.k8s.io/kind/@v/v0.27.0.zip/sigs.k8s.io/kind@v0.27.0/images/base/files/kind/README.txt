This directory is reserved for KIND [^1] internal purposes.

Modifying or depending on the contents of this directory is NOT supported.

Here be dragons.

[^1]: https://kind.sigs.k8s.io/
