---
name: Cleanup 
about: Pay down technical debt, reduce friction, etc.
labels: kind/cleanup

---

<!-- Please use this template while filing an issue to highlight technical debt to be paid down, or friction to be reduced -->

**What should be cleaned up or changed**:

**Why is this needed**:

