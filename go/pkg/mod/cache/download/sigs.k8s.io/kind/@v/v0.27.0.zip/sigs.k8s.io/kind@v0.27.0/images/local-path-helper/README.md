# local-path-helper

This image is the image used for the https://github.com/rancher/local-path-provisioner helper pod.

## Building

You can `make quick` in this directory to build a test image.

To push an actual image use `make push`.